﻿public interface ICar
{
    string Driver { get; }

    string UseBrakes();

    string GasPedal();
}

