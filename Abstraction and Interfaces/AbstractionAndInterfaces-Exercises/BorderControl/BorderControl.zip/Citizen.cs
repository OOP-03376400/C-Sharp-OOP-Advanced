﻿public class Citizen : ITown
{
    public Citizen()
    {
    }
    public string Id { get;  set; }
}

