﻿using System.CodeDom;

public class Robot: ITown
{
    public Robot()
    {
    }
    public string Id { get;  set; }
}

