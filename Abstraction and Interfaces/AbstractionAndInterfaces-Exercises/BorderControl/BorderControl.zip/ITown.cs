﻿public interface ITown
{
    string Id { get; }
}

