﻿public interface ICallable
{
    string Call();
}

