﻿public interface IElectricCar
{
    int Baterry { get; }

}

