﻿public static  class ArrayCreator
{
    public static T[] Create<T>(int lenght, T item)
    {
        T[] array = new T[lenght];

        return array;
    }
}


